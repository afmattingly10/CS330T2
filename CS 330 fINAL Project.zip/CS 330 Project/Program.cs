﻿#include <windows.h>
#include <GL/glut.h>
#include <stdlib.h>

//trees. Need to make several for back of scene
void drawtree(int n)
{
    if (n > 0)
    {
        //////////////////////////
        //stack of matrices
        glPushMatrix();
        glTranslatef(-0.5, 1.0, 0);
        glRotatef(45, 0.0, 0.0, 1.0);
        // 1/sqrt(2)=0.707
        glScalef(0.707, 0.707, 0.707);
        //recursion
        drawtree(n - 1);
        glPopMatrix();

        glPushMatrix();
        glTranslatef(0.5, 1.0, 0);
        glRotatef(-45, 0.0, 0.0, 1.0);
        glScalef(0.707, 0.707, 0.707);
        drawtree(n - 1);
        glPopMatrix();
        //draw a cube
        glutSolidCube(1);
    }
}

void treeInit(int n)
{
    // draw a red tree
    glColor3f(1.0, 0.0, 0.0);
    drawtree(n);
}
void display(void)
{
    glClearColor(1.0, 1.0, 1.0, 1.0);
    glClear(GL_COLOR_BUFFER_BIT);
    glLoadIdentity();
    gluLookAt(0.0, 0.0, 5.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0);
    //initialize with 15 iterations
    treeInit(15);
    glFlush();
}
void reshape(int w, int h)
{
    //reshaoe to aspect ratio
    glViewport(0, 0, (GLsizei)w, (GLsizei)h);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(80, (GLfloat)w / (GLfloat)h, 1.0, 100.0);
    glMatrixMode(GL_MODELVIEW);
}
int main(int argc, char** argv)
{
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_SINGLE);
    glutInitWindowSize(900, 700);
    glutInitWindowPosition(300, 100);
    glutCreateWindow("Pythagoras Tree");
    glutDisplayFunc(display);
    glutReshapeFunc(reshape);
    glutMainLoop();
    return 0;
}

//house 

#include<Windows.h>       // for MS Windows
#include<GL\glut.h>       // GLUT, include glu.h and gl.h
//Note: GLglut.h path depending on the system in use
void init()
{
    // Set display window color to as glClearColor(R,G,B,Alpha)
    glClearColor(0.5, 0.9, 0.4, 0.0);
    // Set projection parameters.
    glMatrixMode(GL_PROJECTION);
    // Set 2D Transformation as gluOrtho2D(Min Width, Max Width, Min Height, Max Height)
    gluOrtho2D(0.0, 800, 0.0, 600);
}
void home()
{
    //Roof
    glClear(GL_COLOR_BUFFER_BIT); 
 //color
    glColor3f(0.3, 0.5, 0.8);
    glBegin(GL_POLYGON);
    glVertex2i(200, 500);
    glVertex2i(600, 500);
    glVertex2i(700, 350);
    glVertex2i(300, 350);
    glEnd();
    // Top of Front Wall
    glColor3f(0.1, 0.5, 0.0);
    glBegin(GL_TRIANGLES);
    glVertex2i(200, 500);
    glVertex2i(100, 350);
    glVertex2i(300, 350);
    glEnd();
    // Front Wall
    glColor3f(0.7, 0.2, 0.3);
    glBegin(GL_POLYGON);
    glVertex2i(100, 350);
    glVertex2i(300, 350);
    glVertex2i(300, 100);
    glVertex2i(100, 100);
    glEnd();
    // Front Door
    glColor3f(0.7, 0.2, 0.9);
    glBegin(GL_POLYGON);
    glVertex2i(150, 250);
    glVertex2i(250, 250);
    glVertex2i(250, 100);
    glVertex2i(150, 100);
    glEnd();


    //side Wall
    glColor3f(0.1, 0.2, 0.3);
    glBegin(GL_POLYGON);
    glVertex2i(300, 350);
    glVertex2i(700, 350);
    glVertex2i(700, 100);
    glVertex2i(300, 100);
    glEnd();
    // window one
    glColor3f(0.2, 0.4, 0.3);
    glBegin(GL_POLYGON);
    glVertex2i(330, 320);
    glVertex2i(450, 320);
    glVertex2i(450, 230);
    glVertex2i(330, 230);
    glEnd();
    glColor3f(0.1, 0.7, 0.5);
    glLineWidth(5);
    glBegin(GL_LINES);
    glVertex2i(390, 320);
    glVertex2i(390, 230);
    glVertex2i(330, 273);
    glVertex2i(450, 273);
    glEnd();
    // window two
    glColor3f(0.2, 0.4, 0.3);
    glBegin(GL_POLYGON);
    glVertex2i(530, 320);
    glVertex2i(650, 320);
    glVertex2i(650, 230);
    glVertex2i(530, 230);
    glEnd();
    glColor3f(0.1, 0.7, 0.5);
    glLineWidth(5);
    glBegin(GL_LINES);
    glVertex2i(590, 320);
    glVertex2i(590, 230);
    glVertex2i(530, 273);
    glVertex2i(650, 273);
    glEnd();

    

    glFlush();
}
int main(int argc, char** argv)
{
    // Initialize GLUT
    glutInit(&argc, argv);
    // Set display mode
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
    // Set top - left display window position.
    glutInitWindowPosition(100, 100);
    // Set display window width and height
    glutInitWindowSize(800, 600);
    // Create display window with the given title
    glutCreateWindow("2D House in OpenGL ");
    // Execute initialization procedure
    init();
    // Send graphics to display window
    glutDisplayFunc(home);
    // Display everything and wait.
    glutMainLoop();
}

// camera movements

include<windows.h>

#include<gl/Gl.h>

#include<gl/Glug.h>

#include<gl/Glut.h>

Void axis(double length)

{
    glPushMatrix();
    glBegin(GL - LINES);
    glVertex3d(0, 0, 0);
    glVertex3d(0, 0, length);
    glEnd();
    glTranslated(0, 0, length - 0.2);
    glutWireCone(0.04, 0.2, 12, 9);
    glPopMatrix();

}

Void displayWire(void)

{

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(-2.0 * 64 / 48.0, 2.0 * 64 / 48.0, -2.0, 2.0, 0.1, 100);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    glutLookAt(2.0, 2.0, 2.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0);
    glClear(GL_COLOR_BUFFER_BIT);
    glColor3d(0, 0, 0); 
    axis(0.5);
    glPushMatrix();
    glRotated(90, 0, 1.0, 0);
   axis(0.5);
    glRotated(-90.0, 1, 0, 0);
    axis(0.5);
   glPopMatrix();
   glPushMatrix();
   glColor3d(0, 0.5, 0.8);
    glTranslated(0.5, 0.5, 0.5); 
    glutWireCube(1.0);
    glPopMatrix();
    glPushMatrix();
    glColor3d(0.5, 0.5, 0.8);
    glTranslated(1.0, 1.0, 0); 
   glutWireSphere(0.25, 10, 8);
    glPopMatrix();
    glPushMatrix();
    glColor3d(0, 0.3, 0.7);
    glTranslated(1.0, 0, 1.0); 
    glutWireCone(0.2, 0.5, 10, 8);
    glPopMatrix();
    glPushMatrix();
    glColor3d(0, 0.1, 0.8);
    glTranslated(1, 1, 1); 
    glutWireCube(0.2);
    glPopMatrix();
    glPushMatrix();
    glColor3d(0.8, 0.5, 0.8);
    glTranslated(0, 1.0, 0); 
    glRotated(90.0, 1, 0, 0);
    glutWireTorus(0.1, 0.3, 10, 10);
    glPopMatrix();
    glFlush();

}
Void processspecialkeys(int key, int xx, int yy)

{

    Float fraction = 0.1f;

    Float lx, lz;

    Switch(key)

{

case S:

        angle -= 0.01f;

        lx = sin(angle);

        lz = cos(angle);

        break;

case W:

        angle += 0.01f;

        lx = sin(angle);

        lz = -cos(angle);

        break;

case A:

        x += lx * fraction;

        z += lz * fraction;

        break;

        Case D:

x -= lx * fraction;

z -= lz * fraction;

break;

}}

lz = sin(angle);

break;

Void main(int argc, char** argv)

{
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT - SINGLE | GLUT - RGB);
    glutInitWindowSize(640, 480);
    glutInitWindowPositiom(100, 100);
    glutCreateWindow(“Transformation Test - wireframes”);
    glutDisplayFunc(displayWire);
    glutSpecialFun(processpecialkeys);
    glClearColor(1.0f, 1.0f, 1.0f, 0.0f);
    glViewport(0, 0, 640, 480);
    glutMainLoop();

}

//texture
unsigned int texture;
glGenTextures(1, &texture);
glBindTexture(GL_TEXTURE_2D, texture);
// set the texture wrapping/filtering options (on the currently bound texture object)
glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
// load and generate the texture
int width, height, nrChannels;
unsigned char* data = stbi_load("container.jpg", &width, &height, &nrChannels, 0);
if (data)
{
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, data);
    glGenerateMipmap(GL_TEXTURE_2D);
}
else
{
    std::cout << "Failed to load texture" << std::endl;
}
stbi_image_free(data);

float vertices[] = {
    // positions          // colors           // texture coords
     0.5f,  0.5f, 0.0f,   1.0f, 0.0f, 0.0f,   1.0f, 1.0f,   // top right
     0.5f, -0.5f, 0.0f,   0.0f, 1.0f, 0.0f,   1.0f, 0.0f,   // bottom right
    -0.5f, -0.5f, 0.0f,   0.0f, 0.0f, 1.0f,   0.0f, 0.0f,   // bottom left
    -0.5f,  0.5f, 0.0f,   1.0f, 1.0f, 0.0f,   0.0f, 1.0f    // top left 
};
glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(6 * sizeof(float)));
glEnableVertexAttribArray(2);
# version 330 core
layout(location = 0) in vec3 aPos;
layout(location = 1) in vec3 aColor;
layout(location = 2) in vec2 aTexCoord;

out vec3 ourColor;
out vec2 TexCoord;

void main()
{
    gl_Position = vec4(aPos, 1.0);
    ourColor = aColor;
    TexCoord = aTexCoord;
}

#version 330 core
out vec4 FragColor;
  
in vec3 ourColor;
in vec2 TexCoord;

uniform sampler2D ourTexture;

void main()
{
    FragColor = texture(ourTexture, TexCoord);
}

glBindTexture(GL_TEXTURE_2D, texture);
glBindVertexArray(VAO);
glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_INT, 0);


//color combos for light sources
GLfloat white_light[] = { 1.0, 1.0, 1.0, 1.0 };

GLfloat green_light[] = { 0.2, 1.0, 0.2, 1.0 };

GLfloat red_light[] = { 1.0, 0.4, 0.4, 1.0 };

GLfloat blue_light[] = { 0.2, 0.2, 1.0, 1.0 };

You can use any of the following properties, or any other properties of interested to you.

// gold

GLfloat gold_ambient[] = { 0.24725, 0.1995, 0.0745, 1.0 };

GLfloat gold_diffuse[] = { 0.75164, 0.60648, 0.22658, 1.0 };

GLfloat gold_specular[] = { 0.628281, 0.555802, 0.366065, 1.0 };

GLfloat gold_shininess[] = { 51.2 };

// silver

GLfloat silver_ambient[] = { 0.19225, 0. 19225, 0. 19225, 1.0 };

GLfloat silver_diffuse[] = { 0.50754, 0. 50754, 0. 50754, 1.0 };

GLfloat silver_specular[] = { 0.508273, 0.508273, 0.508273, 1.0 };

GLfloat silver_shininess[] = { 51.2 };

// copper

GLfloat copper_ambient[] = { 0.2295, 0.08825, 0.0275, 1.0 };

GLfloat copper_diffuse[] = { 0.5508, 0.2118, 0.066, 1.0 };

GLfloat copper_specular[] = { 0.580594, 0.223257, 0.0695701, 1.0 };

GLfloat copper_shininess[] = { 51.2 };